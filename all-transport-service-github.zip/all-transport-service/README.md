# All Transport Service — JNAFAU

A mobile-first, single-page web app prototype for viewing JNAFAU-related bus, Metro and MMTS information.

## Run locally

No build tools or package installation are required.

1. Download or clone this repository.
2. Open `index.html` in a browser for a basic preview.
3. For PWA/service-worker testing, serve the folder over localhost (service workers do not work from `file://`).

If Python is installed:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish with GitHub Pages

1. Create a new **public** GitHub repository.
2. Upload all files and folders from this project. Keep `index.html` in the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish. Open the URL shown in the Pages section.

Every update pushed to the selected branch will be published automatically.

## Project structure

```text
all-transport-service/
├── index.html
├── manifest.webmanifest
├── service-worker.js
├── icons/
│   └── icon.svg
├── README.md
└── .gitignore
```

## Important notes

- This is a static front-end project; it does not require Node.js, npm, a backend, or environment variables.
- The app's transport routes, timings and other displayed information are prototype/sample content from the supplied HTML. Verify them with the relevant transport operators before relying on them for travel.
- The login and student-related screens in this prototype should not be treated as secure authentication or connected institutional records.
- The app uses Google Fonts when an internet connection is available; system fonts remain as fallbacks.
- GitHub Pages provides HTTPS, which is required for installable PWA features and service workers.
- To force clients to receive a fresh offline cache after a future update, increment `CACHE_NAME` in `service-worker.js`.
